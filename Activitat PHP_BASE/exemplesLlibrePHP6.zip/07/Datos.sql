INSERT INTO Libros VALUES(1,'84-415-1544','GNU/Linux','Francisco Charte',1);
INSERT INTO Libros VALUES(2,'84-415-1482','Lenguaje ensamblador','Francisco Charte',1);
INSERT INTO Libros VALUES(3,'84-415-1145','Excel 2007','Francisco Charte',1);
INSERT INTO Libros VALUES(4,'84-415-1568','Windows Server 2008','Francisco Charte',1);
INSERT INTO Editoriales VALUES(1,'Anaya Multimedia','Juan Ignacio Luca de Tena, 15');
INSERT INTO Editoriales VALUES(2,'McGraw-Hill','Valrealty, 13');
