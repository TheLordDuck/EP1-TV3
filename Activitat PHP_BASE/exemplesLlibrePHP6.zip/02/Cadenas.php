<!DOCTYPE html PUBLIC
  "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Cadenas</title>
  <meta http-equiv="Content-type"
      content="text/html;charset=ISO-8859-1" />
</head>
<body>
  <p>
  <?php
     $Mes = "Octubre";
     $Dias = 21;

     echo "El mes de $Mes tiene $Dias d�as<br />";
     echo 'El mes de $Mes tiene $Dias d�as<br />';
     //echo "El mes de _{$Mes}_ tiene _${Dias}_ d�as";
  ?>
  </p>
</body>
</html>
|