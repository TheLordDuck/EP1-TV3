<!DOCTYPE html PUBLIC
  "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title><?php echo "Hola mundo"; ?></title>
  <meta http-equiv="Content-type"
      content="text/html;charset=ISO-8859-1" />
</head>
<body>
  <?php
     $cadena = "Hola";
     echo $cadena;
     Print "<p>Hola PHP</p>";
  ?>
  <hr />
</body>
</html>
|