<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title></title>
</head>

<body>

<?php

$variable = <<< 'FIN'
  Se ha introducido una secuencia
de varias líneas de texto en la
variable $variable, usando para
ello la sintaxis 'nowdoc'.
FIN;

echo $variable;

?>

</body>

</html>