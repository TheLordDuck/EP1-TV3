﻿<!DOCTYPE html PUBLIC
  "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Unicode</title>
  <meta http-equiv="Content-type"
      content="text/html;charset=utf-8" />
</head>
<body>
  <h1>Unicode</h1>
<p>
<?php

$var = "トウキョウ";
echo "La cadena $var tiene " . strlen($var) . " caracteres de longitud";


?></p>
</body>
</html>