<?php
if (!isset($_FILES["file"]) or count($_FILES["file"])==0) {
    return "";
}

$carpetaMoverArchivos="upload/";

$source = $_FILES["file"]["tmp_name"];
$fileName = $_FILES["file"]["name"];
$destination = $carpetaMoverArchivos.$fileName;

// comprovamos si ya existe el archivo.
// comentar estas lineas si deseamos que se pueda sobreescribir
if (file_exists($destination)) {
    echo json_encode(["result"=>0, "time"=>$_POST["time"], "fileName"=>$fileName, "error"=>"el archivo ya existe"]);
    return;
}

// por seguridad no permitimos archivos con extension .php
$notAllowedExtension = ["php", "php3", "php4", "php4"];
$ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
if (in_array($ext, $notAllowedExtension)) {
    echo json_encode(["result"=>0, "time"=>$_POST["time"], "fileName"=>$fileName, "error"=>"extension no permitida"]);
    return;
}

// movemos el archivo
if (move_uploaded_file($source, $destination)) {
    echo json_encode(["result"=>1, "time"=>$_POST["time"], "fileName"=>$fileName, "error"=>""]);
} else {
    echo json_encode(["result"=>0, "time"=>$_POST["time"], "fileName"=>$fileName, "error"=>"no se ha podido mover el archivo"]);
}
?>
