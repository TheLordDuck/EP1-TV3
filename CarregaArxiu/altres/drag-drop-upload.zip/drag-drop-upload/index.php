<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ejemplo Arrastras y Soltar (Drag and Drop)</title>
    <link href="upload.css" type="text/css" rel="stylesheet">
</head>
<body>

    <div class="wrapper">

        <h1>Ejemplo Arrastras y Soltar (Drag and Drop) con JavaScript y PHP</h1>

        <div id="uploader">
            <div>Arrastra y suelta los archivos aquí<br><br>Tamaño máximo por archivo de <?php echo ini_get("upload_max_filesize");?></div>
        </div>

        <div id="filesList"></div>

    </div>

</body>
</html>

<script src="upload.js"></script>
